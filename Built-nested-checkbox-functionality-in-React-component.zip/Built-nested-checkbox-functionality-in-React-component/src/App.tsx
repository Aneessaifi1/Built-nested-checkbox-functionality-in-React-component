import React from 'react';
import NestedCheckbox from './nestedCheckbox'
function App() {
  return (
    <div className="App">
       <NestedCheckbox />
    </div>
  );
}

export default App;
